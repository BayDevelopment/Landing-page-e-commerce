<?php
require '../tahuonline/connection/function.php';
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Welcome | Tahu Crispy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

    <!-- link style css -->
    <link rel="stylesheet" href="../tahuonline/assets/css/style.css">

    <!-- link icon bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <!-- Font awesome cdn -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <main>
        <style>
            .icon-toogle {
                color: #cff09e;
            }

            @media screen and (min-width: 1024px) {
                .navbar-mobile {
                    display: none;
                }

                .navbar-desktop {
                    display: block;
                }
            }
        </style>
        <section>
            <!-- navbar mobile -->
            <nav class="navbar fixed-top navbar-mobile">
                <div class="container">
                    <a class="navbar-brand" href="#">Tahu Crispyku</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas"
                        data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar"
                        aria-label="Toggle navigation">
                        <span class="icon-toogle"><i class="fa-solid fa-bars"></i></span>
                    </button>
                    <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar"
                        aria-labelledby="offcanvasDarkNavbarLabel">
                        <div class="offcanvas-header">
                            <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Menu Crispyku</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"
                                aria-label="Close"></button>
                        </div>
                        <div class="offcanvas-body">
                            <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                                <li class="nav-item">
                                    <a class="nav-link active" aria-current="page" href="#"><span><i
                                                class="fa-solid fa-house"></i></span> Beranda</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#"><span><i class="fa-solid fa-list"></i></span> Daftar
                                        menu</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#"><span><i
                                                class="fa-solid fa-right-to-bracket"></i></span> Login</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>

            <!-- navbar mobile -->
            <nav class="navbar navbar-expand-lg navbar-desktop">
                <div class="container">
                    <a class="navbar-brand" href="#">Tahu Crispyku</a>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav ms-auto">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#"><span><i
                                            class="fa-solid fa-house"></i></span> Beranda</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#"><span><i class="fa-solid fa-list"></i></span> Daftar
                                    menu</a>
                            </li>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#"><span><i class="fa-solid fa-right-to-bracket"></i></span>
                                    Login</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </section>

        <!-- section two -->
        <style>
            .btn-native {
                padding: 10px;
                background-color: #cff09e;
                text-decoration: none;
                color: #4da4a4;
                box-shadow: 1px 2px 3px white;
                border-radius: 4px;
                transition: .3s;
            }

            .btn-native:hover {
                padding: 10px;
                background-color: #4da4a4;
                text-decoration: none;
                color: #cff09e;
                box-shadow: 1px 2px 3px #cff09e;
                border-radius: 4px;
                transition: .3s;
                border: 1px solid #cff09e;
            }

            .text-kedua {
                font-size: 40px;
                font-family: 'Caveat', cursive;
                color: black;
            }

            .size-h5-section-kedua {
                font-size: 30px;
            }

            @media screen and (max-width: 768px) {
                .img-mobile {
                    width: 360px;
                    margin-top: 40px;
                }

                .col-mobile {
                    width: 350px;
                }

                .section-kedua {
                    margin-top: 20px;
                }
            }
        </style>
        <section class="section-kedua">
            <div class="container text-center">
                <div class="row">
                    <div class="col-lg-5 ">
                        <div class="container">
                            <h3 class="text-start fw-semibold size-h3-section-kedua mb-3 text-kedua">Tahu <span
                                    class="span-kedua">Crispyku</span></h3>
                            <h5 class="text-start size-h5-section-kedua mb-4 col-mobile">adalah sebuah aplikasi website
                                E-commerce
                                yang
                                berguna serta membantu
                                anda
                                dalam melakukan pemesanan
                                makanan atau jajanan yakni tahu crispy</h5>
                            <div class=" text-start mt-4">
                                <a class="btn-native fw-semibold" href="selengkapnya.php" role="button">Lihat menu
                                    <span><i class="fa-brands fa-odysee"></i></span></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="container text-end">
                            <img src="../tahuonline/assets/img/undraw_business_deal_re_up4u.svg" alt="" width="600"
                                class="img-mobile">
                        </div>
                    </div>
                </div>
            </div>
        </section>


    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
        crossorigin="anonymous"></script>
</body>

</html>