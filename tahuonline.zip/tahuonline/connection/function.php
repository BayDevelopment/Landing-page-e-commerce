<?php
// koneksi database
$localhost = "localhost";
$username = "root";
$password = "";
$database = "tahucrispy";

$con = mysqli_connect($localhost, $username, $password, $database);

if (!$con) {
    echo "<script>
    alert('Mohon maaf koneksi gagal, silahkan coba lagi!')
        </script>";
} else {
    // echo "koneksi berhasil";
}
?>